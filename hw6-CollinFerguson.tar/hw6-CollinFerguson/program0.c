/*
Collin L. Ferguson
Collin.l.ferguson@und.edu
hw6: Semaphores
 */

#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<sys/sem.h>
//#include<sys/ipc.h>
#include<sys/stat.h>
#include<errno.h>

#define SEM_KEY 1

int main()
{

	int semIdent;

	key_t key = SEM_KEY;


	if((semIdent = semget(key, 1, IPC_CREAT | IPC_EXCL | S_IRWXU | S_IRWXG | S_IRWXO)) == -1)
	{
		printf("Semaphore did not initialize correctly or already exists! Please check that all previous Semaphores were killed.\n");
		return 0;
	}

	//semun definition from linux man pages on semctl
	union semun
	{
		int              val;    /* Value for SETVAL */
		struct semid_ds *buf;    /* Buffer for IPC_STAT, IPC_SET */
		unsigned short  *array;  /* Array for GETALL, SETALL */
		struct seminfo  *__buf;  /* Buffer for IPC_INFO
								   (Linux-specific) */
	}sem_attr;

	sem_attr.val = 1;

	semctl(semIdent, 0, SETVAL, sem_attr);
	printf("Executing process #0.\n");

	return 0;
}

