/*
Collin L. Ferguson
Collin.l.ferguson@und.edu
hw6: Semaphores
 */

#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<sys/sem.h>
#include<errno.h>

#define SEM_KEY 1

int main()
{
	key_t key = SEM_KEY;
	int semIdent = semget(key, 0, 0);
	if(semIdent == -1){exit(0);}
	if(semctl(semIdent, 0, GETVAL) == 2)
	{
		union semun
		{
			int              val;    /* Value for SETVAL */
			struct semid_ds *buf;    /* Buffer for IPC_STAT, IPC_SET */
			unsigned short  *array;  /* Array for GETALL, SETALL */
		    struct seminfo  *__buf;  /* Buffer for IPC_INFO
									   (Linux-specific) */
		}sem_attr;

		sem_attr.val = 3;

		semctl(semIdent, 0, SETVAL, sem_attr);

		printf("Executing process #2.\n");
	}
	return 0;
}
