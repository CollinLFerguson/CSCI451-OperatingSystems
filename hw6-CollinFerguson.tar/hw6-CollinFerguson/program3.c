/*
Collin L. Ferguson
Collin.l.ferguson@und.edu
hw6: Semaphores
 */

#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<sys/sem.h>
#include<errno.h>

#define SEM_KEY 1

int main()
{
	key_t key = SEM_KEY;
	int semIdent = semget(key, 0, 0);

	if(semIdent == -1){exit(0);}

	if(semctl(semIdent, 0, GETVAL) == 3)
	{
		semIdent = semctl(semget(key, 0, 0), 0, IPC_RMID);
		printf("Executing process #3.\n");
		return 0;
	}

	return 0;
}
